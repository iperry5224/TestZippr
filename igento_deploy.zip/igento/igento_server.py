"""
IGENTO - MCP Learning App
=========================
A simple MCP server to learn Model Context Protocol concepts.
Exposes: Tools (actions), Resources (data), and Prompts (templates).

Run: python igento_server.py
Test: Add to Cursor MCP config or use MCP Inspector.

Learn more: https://modelcontextprotocol.io
"""

import sys
from datetime import datetime

from mcp.server.fastmcp import FastMCP

# Create MCP server - name shows in client UI
mcp = FastMCP(
    name="Igento",
    instructions="Igento is a learning MCP server. Use the tools and resources to explore MCP.",
)

# =============================================================================
# TOOLS - Functions the AI can call (like API endpoints that do things)
# =============================================================================

@mcp.tool()
def add_numbers(a: int, b: int) -> int:
    """Add two numbers together. Simple example of a tool with typed inputs."""
    return a + b


@mcp.tool()
def greet(name: str, style: str = "friendly") -> str:
    """Generate a greeting for someone.
    
    Args:
        name: The person's name
        style: Greeting style - 'friendly', 'formal', or 'casual'
    """
    styles = {
        "friendly": f"Hey {name}! Great to meet you!",
        "formal": f"Good day, {name}. Pleased to make your acquaintance.",
        "casual": f"Yo {name}, what's up?",
    }
    return styles.get(style, styles["friendly"])


@mcp.tool()
def get_timestamp() -> str:
    """Get the current date and time. Useful for testing tool invocation."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@mcp.tool()
def echo_message(message: str, repeat: int = 1) -> str:
    """Echo a message back. Good for testing that tools receive parameters correctly.
    
    Args:
        message: The message to echo
        repeat: How many times to repeat it (default 1)
    """
    return (message + " ") * repeat


# =============================================================================
# RESOURCES - Read-only data the AI can load into context (like GET endpoints)
# =============================================================================

@mcp.resource("igento://info/about")
def get_about() -> str:
    """Information about the Igento MCP server."""
    return """
# Igento MCP Server

A learning project for Model Context Protocol (MCP).

## What is MCP?
MCP lets AI assistants connect to external data and tools in a standardized way.
- **Tools** = Actions the AI can execute (like API POST)
- **Resources** = Data the AI can read (like API GET)
- **Prompts** = Reusable templates for common tasks

## Resources in this server:
- igento://info/about - This file
- igento://help/{topic} - Help on a topic

## Tools in this server:
- add_numbers - Add two integers
- greet - Generate a greeting
- get_timestamp - Current time
- echo_message - Echo back a message
"""


@mcp.resource("igento://help/{topic}")
def get_help(topic: str) -> str:
    """Get help on an MCP topic. Try: tools, resources, prompts, or concepts."""
    help_content = {
        "tools": """
## MCP Tools
Tools are functions the AI can call. They can take parameters and return results.
- Define with @mcp.tool() decorator
- Use type hints for parameters (AI gets a schema)
- Docstring becomes the tool description

Example: add_numbers(a: int, b: int) -> int
""",
        "resources": """
## MCP Resources
Resources are URI-addressable data. The AI reads them to get context.
- Define with @mcp.resource("uri://path/{param}") 
- URI template params map to function args
- Only loaded when requested (lazy)

Example: igento://help/{topic}
""",
        "prompts": """
## MCP Prompts
Prompts are reusable templates that help structure AI interactions.
- Define with @mcp.prompt()
- Can take parameters to customize the prompt
- Great for consistent workflows

Example: prompt_template(topic: str) -> str
""",
        "concepts": """
## MCP Core Concepts
1. **Server** - Exposes tools, resources, prompts
2. **Client** - Cursor, Claude Desktop, or custom app
3. **Transport** - stdio (local) or HTTP (remote)
4. **Protocol** - JSON-RPC over the transport

STDIO: Server runs as subprocess, client talks via stdin/stdout.
HTTP: Server runs as web server, client makes HTTP requests.
""",
    }
    return help_content.get(topic.lower(), f"No help found for '{topic}'. Try: tools, resources, prompts, concepts")


# =============================================================================
# PROMPTS - Reusable templates for AI interactions
# =============================================================================

@mcp.prompt()
def learn_mcp(topic: str, depth: str = "brief") -> str:
    """Generate a prompt to learn about an MCP topic.
    
    Args:
        topic: What to learn (e.g., tools, resources, architecture)
        depth: How deep - 'brief', 'detailed', or 'deep_dive'
    """
    depth_instructions = {
        "brief": "Give a 2-3 sentence overview.",
        "detailed": "Explain with examples and key points.",
        "deep_dive": "Provide a comprehensive explanation with best practices and gotchas.",
    }
    instr = depth_instructions.get(depth, depth_instructions["brief"])
    return f"Please explain MCP {topic} for someone learning. {instr}"


@mcp.prompt()
def debug_tool(tool_name: str, error_message: str) -> str:
    """Create a debugging prompt when a tool fails.
    
    Args:
        tool_name: The tool that failed
        error_message: The error received
    """
    return f"""I'm debugging an MCP tool called "{tool_name}".

Error: {error_message}

Please help me:
1. Identify the likely cause
2. Suggest how to fix it
3. Mention common MCP tool pitfalls (e.g., stdout vs stderr for logging)
"""


# =============================================================================
# MAIN - Run the server
# =============================================================================

def main():
    import argparse
    p = argparse.ArgumentParser(description="Igento MCP server")
    p.add_argument(
        "--transport",
        choices=["stdio", "streamable-http"],
        default="stdio",
        help="stdio for Cursor/Claude, streamable-http for MCP Inspector (localhost:8000)",
    )
    args = p.parse_args()
    msg = f"Igento MCP server starting ({args.transport})... Use Cursor or MCP Inspector to connect."
    print(msg, file=sys.stderr)
    mcp.run(transport=args.transport)


if __name__ == "__main__":
    main()
